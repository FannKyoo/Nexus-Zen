"""
URL configuration for fannweb project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from kampus_app import views
from django.conf import settings             # Tambahkan ini
from django.conf.urls.static import static  # Tambahkan ini

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.beranda, name='beranda'), # <--- Path kosong '' berarti halaman utama (home)
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

admin.site.site_header = "Nexus Zen"
admin.site.site_title = "Nexus Zen Admin"
admin.site.index_title = "Welcome to Nexus Zen Admin Dashboard"